Starter script is clf.py for testing the data. This produces a final.csv file which is output.
The output has
	1st column output of Deep learning model
	2nd column is query
	3rd column is output of svm
	4th column is output of naive bayes
	5th column is actual prediction
	6th column is meta data associated with query found on cornell law website 
